package com.example.productmono;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMonoApplicationTests {

	@Test
	void contextLoads() {
	}

}
