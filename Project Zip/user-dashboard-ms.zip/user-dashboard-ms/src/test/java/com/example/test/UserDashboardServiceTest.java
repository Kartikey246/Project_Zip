package com.example.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.model.UserOwnedPolicy;
import com.repo.UOPRepo;
import com.service.AppService;

public class UserDashboardServiceTest {
	 @InjectMocks
	 private AppService service;
	 @Mock
	 private UOPRepo repo;
	 @SuppressWarnings("deprecation")
	@BeforeEach
	 void init() {
	        MockitoAnnotations.initMocks(this);
	  }
//	 @Test
//	 void testBuyPolicy() {
//		 UserOwnedPolicy uop = new UserOwnedPolicy(1l, 1l, 1l, 1.0, 1, 1, "approved", Date.valueOf(LocalDate.now()));
//		 when(repo.save(uop)).thenReturn(uop);
//		 when(service.buyPolicies(1l, 1.0)).thenReturn("added");
//		 assertEquals("added", service.buyPolicies(1l, 1.0));
//		 
//}
	 @Test
	    void testGetAllPolicies() {
	        List<UserOwnedPolicy> policies = Arrays.asList(
	        		 new UserOwnedPolicy(1l, 1l, 1l, 1.0, 1, 1, "approved", Date.valueOf(LocalDate.now())),
	        		 new UserOwnedPolicy(1l, 1l, 1l, 1.0, 1, 1, "approved", Date.valueOf(LocalDate.now()))
	        );
	        when(repo.findAll()).thenReturn(policies);
	        when(service.loadUserOwnedPolicies(1l)).thenReturn(policies);
	        List<UserOwnedPolicy> result = service.loadUserOwnedPolicies(1l);

	        assertEquals(2, result.size());
	        
	    }
	
	
	 @Test
	    void testDeletePolicy() {
	        long policyId = 1L;

	        UserOwnedPolicy policyToDelete = new UserOwnedPolicy(1l, 1l, 1l, 1.0, 1, 1, "approved", Date.valueOf(LocalDate.now()));
	        when(repo.findById(policyId)).thenReturn(Optional.of(policyToDelete));

	        service.deletePolicy(policyId);

	        verify(repo, times(1)).findById(policyId);
	    }
}
