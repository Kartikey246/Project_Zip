package com.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.exception.PolicyNotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.AllItemsInCartResponse;
import com.model.CartEntity;
import com.model.Discount;
import com.model.Policy;
import com.model.UserOwnedPolicy;
import com.repo.UOPRepo;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class AppService {
	@Autowired
	@Qualifier("webclient")
	private WebClient.Builder builder;

	@Autowired
	private UOPRepo repo;

	private HashMap<Long, Discount> discountMap = new HashMap<>();

	@CircuitBreaker(fallbackMethod = "fbm", name = "circuit")
	public String getDiscount() {

		String discountServiceURL = "http://discount-service/loadAll";
		List<Discount> discounts = builder.build().get().uri(discountServiceURL).retrieve().bodyToFlux(Discount.class)
				.collectList().block();
		for (Discount dis : discounts) {
			discountMap.put(dis.getPolicyId(), dis);
		}
		return "added";

	}

	@CircuitBreaker(fallbackMethod = "fbm", name = "circuit")
	public String buyPolicies(Long userId, Double rate) {
		ObjectMapper mapper = new ObjectMapper();
		String cartServiceURL = "http://cart-service/insurancecart/getAllItemsFromCart/" + userId;
		AllItemsInCartResponse crt = builder.build().get().uri(cartServiceURL).retrieve().bodyToFlux(AllItemsInCartResponse.class).last()
				.block();
		System.out.println(crt);
		String policyServiceURL="http://policy-service/policies/loadPolicies/"+ crt.getListOfPolicyIds().stream()
		.map(String::valueOf).collect(Collectors.joining(","));
		//getDiscount();
		
		
			List<Policy> policies= builder.build()
					.get()
					.uri(policyServiceURL)
					.retrieve()
					.bodyToFlux(Policy.class)
					.collectList()
					.block();

			for (Policy policy : policies) {
				UserOwnedPolicy uop = null;
				Double dis=0.0;
				 				uop = UserOwnedPolicy.builder().userId(userId).policyId(policy.getPolicy_id())
						.startDate(Date.valueOf(LocalDate.now())).status("Approved")
						.userPremium(policy.getStandardPremium() * rate * (1.0 - dis))
						.userCoverage(policy.getCoverageAmount()).userTerm(policy.getTerm()).build();
				repo.save(uop);
			}
		

		return "added";

	}

	

	public List<UserOwnedPolicy> loadUserOwnedPolicies(Long userId) {

		return repo.findAllByuserId(userId);

	}

	public void deletePolicy(long id) {
		repo.findById(id).orElseThrow(() -> new PolicyNotFoundException(id));

		repo.deleteById(id);

	}

	public String fbm(Throwable t) {
		System.out.println("server down");
		return null;
	}

	public List<Policy> fallbackMethod(Throwable t) {
		System.out.println("server down");
		return null;
	}
}
