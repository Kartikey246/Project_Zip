import AdminDashboard from "./AdminDashboard";

export default function Admin() {
    const isAdmin = localStorage.getItem('userRole') === 'Admin';
   return (
    <div>
        {isAdmin ?
            <AdminDashboard/>: <div>Not Logged in as Admin</div>
        }
    </div>
   )
}