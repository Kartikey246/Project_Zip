package com.example.insurancecartmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceCartMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
