package com.example.dao;


import com.example.entity.Orders;

public interface OrdersDao {
    public abstract void addOrder(final Orders order);
}
