package com.example.feedback;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.dto.FeedbackRequestDTO;
import com.dto.FeedbackResponseDTO;
import com.entity.FeedbackEntity;

import com.repository.FeedbackRepository;
import com.service.FeedbackServiceImpl;

public class FeedbackApplicationTests {

    @InjectMocks
    private FeedbackServiceImpl feedbackService;

    @Mock
    private FeedbackRepository feedbackRepository;

    @BeforeEach
    public void setUp() {
        feedbackRepository = mock(FeedbackRepository.class);
    }

    @Test
    public void testAddFeedback() {
        // Arrange
        FeedbackRequestDTO feedbackDTO = FeedbackRequestDTO.builder()
                .userName("John Doe")
                .comment("Great service!")
                .build();

        Long uopId = 1L;

        FeedbackEntity feedbackEntity = FeedbackEntity.builder()
                .uopId(uopId)
                .userName(feedbackDTO.getUserName())
                .comment(feedbackDTO.getComment())
                .build();

        when(feedbackRepository.save(any(FeedbackEntity.class))).thenReturn(feedbackEntity);

        // Act
        ResponseEntity<String> response = feedbackService.addFeedback(feedbackDTO, uopId);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Feedback has been created successfully", response.getBody());
        verify(feedbackRepository).save(any(FeedbackEntity.class));
    }

    @Test
    public void testGetAllFeedback() {
        // Arrange
        List<FeedbackEntity> feedbackEntities = new ArrayList<>();
        feedbackEntities.add(FeedbackEntity.builder().userName("User1").comment("Comment1").build());
        feedbackEntities.add(FeedbackEntity.builder().userName("User2").comment("Comment2").build());

        when(feedbackRepository.findAll()).thenReturn(feedbackEntities);

        // Act
        ResponseEntity<List<FeedbackResponseDTO>> response = feedbackService.getAllFeedback();

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(feedbackEntities.size(), response.getBody().size());
        verify(feedbackRepository).findAll();
    }
}
