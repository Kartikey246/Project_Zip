package com.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.dto.FeedbackRequestDTO.FeedbackRequestDTOBuilder;
import com.dto.FeedbackResponseDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "feedback")
public class FeedbackEntity {

	@Id
	@GeneratedValue
	private Long feedbackId;
	private Long uopId;
	private String userName;
	private String comment;
	
	public FeedbackResponseDTO toDto() {
		return FeedbackResponseDTO.builder().comment(comment).feedbackId(feedbackId).userName(userName).build();
	}

}
