package com.example.policymsproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyMsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
