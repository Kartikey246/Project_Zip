package com.model;

public enum InsuranceType {
HEALTH,LIFE,VEHICLE
}
