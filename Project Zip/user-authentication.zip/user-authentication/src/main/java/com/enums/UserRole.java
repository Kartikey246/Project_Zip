package com.enums;

public enum UserRole {
   Admin,User,ApplicationOwner
}
